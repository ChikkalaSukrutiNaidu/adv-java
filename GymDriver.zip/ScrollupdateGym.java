package gym;

import java.sql.*;

public class ScrollupdateGym {

    Connection con;
    Statement stmt;

    
    public void createConnection() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/gym_db",
                    "root",
                    "Sukruti@04");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    public void scrollableUpdatableRS() {

        String query = "SELECT * FROM member";

        try {

            stmt = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = stmt.executeQuery(query);

            
            rs.afterLast();

            
            while (rs.previous()) {

                
                if (rs.getInt("mem_id") == 303) {

                    rs.updateString("plan", "12 Months");
                    rs.updateDouble("fee", 4500);
                    rs.updateRow();
                }

                System.out.println("Member ID : " + rs.getInt("mem_id"));
                System.out.println("Name      : " + rs.getString("name"));
                System.out.println("Plan      : " + rs.getString("plan"));
                System.out.println("Fee       : " + rs.getDouble("fee"));
            }

            
            rs.absolute(3);

            System.out.println("\nThird Record");
            System.out.println("Member ID : " + rs.getInt("mem_id"));
            System.out.println("Name      : " + rs.getString("name"));
            System.out.println("Plan      : " + rs.getString("plan"));
            System.out.println("Fee       : " + rs.getDouble("fee"));

          
            rs.moveToInsertRow();

            rs.updateInt("mem_id", 501);
            rs.updateString("name", "Kiran");
            rs.updateString("plan", "6 Months");
            rs.updateDouble("fee", 6500);

            rs.insertRow();

            System.out.println("\nNew Member Inserted.");

          
            rs.moveToCurrentRow();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}