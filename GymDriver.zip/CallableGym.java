package gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
import java.sql.CallableStatement;
import java.sql.SQLException;
public class CallableGym {
    Connection con;
    CallableStatement cs;
    public void createConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
             		con = DriverManager.getConnection(
            	    "jdbc:mysql://localhost:3306/gym_db",
            	    "root",
            	    "Sukruti@04"
            	);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void createCallableProcedure(int mem_id) {
        try {
            cs = con.prepareCall("{call get_member_details(?,?)}");
            cs.setInt(1, mem_id);
            cs.registerOutParameter(2, Types.VARCHAR);
            cs.execute();
            System.out.println("Member Name(Procedure) : " + cs.getString(2));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void createCallableFunction(int mem_id) {
        try {
            cs = con.prepareCall("{ ? = call get_name_from_member(?) }");
            cs.registerOutParameter(1, Types.VARCHAR);
            cs.setInt(2, mem_id);
            cs.execute();
            System.out.println("Member Name(Function) : " + cs.getString(1));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
