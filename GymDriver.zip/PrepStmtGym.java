package gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.xdevapi.Statement;

public class PrepStmtGym {
	Connection con;
	Statement stmt;
	 public void createConnection() {

	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");

	             con = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/gym_db",
	                    "root",
	                    "Sukruti@04");

	        } catch (ClassNotFoundException | SQLException e) {

	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	 }
	 public void insertGym(int mem_id,String name,String plan,int fee) {
		 try {
			String query="INSERT INTO member VALUES(?,?,?,?)";
			 PreparedStatement psmt=con.prepareStatement(query);
			 psmt.setInt(1, mem_id);
			 psmt.setString(2,name);
			 psmt.setString(3,plan);
			 psmt.setInt(4,fee);
			 int rows=psmt.executeUpdate();
			 System.out.println("Rows inserted: "+rows);
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
		 
	 }
	 public void getGym(int mem_id) {

	        try {

	            String query = "SELECT * FROM member WHERE mem_id=?";

	            PreparedStatement psmt = con.prepareStatement(query);

	            psmt.setInt(1, mem_id);

	            ResultSet rs = psmt.executeQuery();

	            while (rs.next()) {

	                System.out.println("Member ID : " + rs.getInt(1));
	                System.out.println("Name     : " + rs.getString(2));
	                System.out.println("Plan     : " + rs.getString(3));
	                System.out.println("Fee   : " + rs.getInt(4));
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 public void updateGym(int mem_id, int fee) {

	        try {

	            String query = "UPDATE member SET fee=? WHERE mem_id=?";

	            PreparedStatement psmt = con.prepareStatement(query);

	            psmt.setInt(1, fee);
	            psmt.setInt(2, mem_id);

	            int rows = psmt.executeUpdate();

	            System.out.println("Rows Updated : " + rows);

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 public void deleteGym(int mem_id) {

	        try {

	            String query = "DELETE FROM member WHERE mem_id=?";

	            PreparedStatement psmt = con.prepareStatement(query);

	            psmt.setInt(1, mem_id);

	            int rows = psmt.executeUpdate();

	            System.out.println("Rows Deleted : " + rows);

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public void getGym() {

	        try {

	            String query = "SELECT * FROM member";

	            PreparedStatement psmt = con.prepareStatement(query);

	            ResultSet rs = psmt.executeQuery();

	            while (rs.next()) {

	                System.out.println("Mem ID : " + rs.getInt(1));
	                System.out.println("Name     : " + rs.getString(2));
	                System.out.println("Plan    : " + rs.getString(3));
	                System.out.println("Fee  : " + rs.getInt(4));
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
