package gym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Gym {

    Connection con;
    Statement stmt;

    public void createConnection() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/gym_db",
                    "root",
                    "Sukruti@04");

        } catch (ClassNotFoundException | SQLException e) {

            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void viewDetails() {

        try {

            String query = "select * from member";

            stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {

                System.out.println("mem_id: " + rs.getInt(1));
                System.out.println("name: " + rs.getString(2));
                System.out.println("plan: " + rs.getString(3));
                System.out.println("fee: " + rs.getInt(4));

            }

        } catch (SQLException e) {

            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void insertDetails() {

        try {

            int mem_id = 104;
            String name = "rahul";
            String plan = "three month";
            int fee = 6000;

            String query = "insert into member values("
                    + mem_id + ",'"
                    + name + "','"
                    + plan + "',"
                    + fee + ")";

            Statement stmt = con.createStatement();

            int rows = stmt.executeUpdate(query);

            System.out.println(rows + "inserted");

        } catch (SQLException e) {

            e.printStackTrace();
        }

    }

    public void updateDetails() {

        try {

            int mem_id = 101;
            int fee = 10000;

            String query = "update member set fee="
                    + fee
                    + " where mem_id="
                    + mem_id;

            Statement stmt = con.createStatement();

            int row = stmt.executeUpdate(query);

            System.out.println(row + "update recorded");

        } catch (SQLException e) {

            e.printStackTrace();
        }

    }

}