package gym;

public class GymDriver {
//
	public static void main(String[] args) {
//		Gym gy=new Gym();
//		gy.createConnection();
//		gy.viewDetails();
		//gy.insertDetails();
		//gy.updateDetails();
		// TODO Auto-generated method
//		 PrepStmtGym obj=new PrepStmtGym();
//	        obj.createConnection();
//	        obj.insertGym(110, "Siri", "Nine months", 50000);
//	        obj.getGym(107);
//	        obj.updateGym(108, 70000);
//	        obj.deleteGym(106);
//	        obj.getGym();
//		CallableGym obj = new CallableGym();
//        obj.createConnection();
//        obj.createCallableProcedure(102);
//        System.out.println();
//        obj.createCallableFunction(102);
//	    }	
//	}

//        BatchupdateGym obj = new BatchupdateGym();
//
//        obj.createConnection();
//
//        obj.batchInsert();
//
//        obj.batchUpdate();
//        
//        obj.displayMembers();
		 ScrollupdateGym obj = new ScrollupdateGym();

	        obj.createConnection();

	        obj.scrollableUpdatableRS();

    }

}


