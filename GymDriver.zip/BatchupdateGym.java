package gym;

import java.sql.*;
import java.util.*;

public class BatchupdateGym {

    Connection con;
    public void createConnection() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/gym_db",
                    "root",
                    "Sukruti@04");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  
    public void batchInsert() {

        try {

            String query = "INSERT INTO member VALUES(?,?,?,?)";

            PreparedStatement psmt = con.prepareStatement(query);

            ArrayList<String> members = new ArrayList<>();

            members.add("301,Ram,6 Months,5000");
            members.add("302,Sita,12 Months,7000");
            members.add("303,Ravi,3 Months,3000");
            members.add("304,Pooja,9 Months,6000");

            for (String member : members) {

                String[] columns = member.split(",");

                psmt.setInt(1, Integer.parseInt(columns[0]));
                psmt.setString(2, columns[1]);
                psmt.setString(3, columns[2]);
                psmt.setDouble(4, Double.parseDouble(columns[3]));

                psmt.addBatch();
            }

            int[] rows = psmt.executeBatch();

            System.out.println(rows.length + " Rows Inserted");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Batch Update
    public void batchUpdate() {

        try {

            String query = "UPDATE member SET fee=? WHERE mem_id=?";

            PreparedStatement psmt = con.prepareStatement(query);

            ArrayList<String> members = new ArrayList<>();

            members.add("5500,201");
            members.add("7500,202");
            members.add("3500,203");

            for (String member : members) {

                String[] columns = member.split(",");

                psmt.setDouble(1, Double.parseDouble(columns[0]));
                psmt.setInt(2, Integer.parseInt(columns[1]));

                psmt.addBatch();
            }

            int[] rows = psmt.executeBatch();

            System.out.println(rows.length + " Rows Updated");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void displayMembers() {

        try {

            String query = "SELECT * FROM member";

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(query);

            System.out.println("mem_id\tname\tplan\tfee");

            while (rs.next()) {

                System.out.println(
                    rs.getInt("mem_id") + "\t" +
                    rs.getString("name") + "\t" +
                    rs.getString("plan") + "\t" +
                    rs.getDouble("fee")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}