package gym;
import java.sql.*;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;
public class RowSetGym {
    public void dbOperations() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/gym_db",
                    "root",
                    "Sukruti@04");
            con.setAutoCommit(false);
            CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
            crs.setUrl("jdbc:mysql://localhost:3306/gym_db");
            crs.setUsername("root");
            crs.setPassword("Sukruti@04");
            crs.setCommand("SELECT * FROM member");
            crs.execute();
            while (crs.next()) {
                System.out.println("Member ID : " + crs.getInt("mem_id"));
                System.out.println("Name      : " + crs.getString("name"));
                System.out.println("Plan      : " + crs.getString("plan"));
                System.out.println("Fee       : " + crs.getString("fee"));
            }
            crs.absolute(4);
            System.out.println("\nFourth Record");
            System.out.println("Member ID : " + crs.getInt("mem_id"));
            System.out.println("Name      : " + crs.getString("name"));
            System.out.println("Plan      : " + crs.getString("plan"));
            System.out.println("Fee       : " + crs.getString("fee"));
            crs.updateString("plan", "12 Months");
            crs.updateString("fee", "8000");
            crs.updateRow();
            crs.acceptChanges(con);
            con.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}